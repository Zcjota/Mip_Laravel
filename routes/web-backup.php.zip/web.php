<?php
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/main', function () {
    return view('contenido/contenido');
})->name('main');

//Equipos
Route::get('/equipos/listarTecnicoEquipo', 'EquiposController@listadoEquipoConTecnicos');
Route::get('/equipos', 'EquiposController@index');
Route::get('/equipos/listadoActivo', 'EquiposController@listadoActivo');
Route::post('/equipos/registrar', 'EquiposController@store');
Route::put('/equipos/actualizar', 'EquiposController@update');
Route::get('/Mip/equipos/listar', 'EquiposController@listadoEquipo');
Route::get('/Mip/equipos/listarOperaciones', 'EquiposController@listadoEquipoOperaciones');

//Reserva
Route::get('/pruebaNro', 'ReservaController@objNroOrden');
Route::put('/reservas/vincularOT', 'ReservaController@vincularOT');
Route::get('/reserva/listarOTSinAsignacion', 'ReservaController@listarOTSinAsignacion');
Route::get('/reserva/obtCodPersonal', 'ReservaController@obtCodPersonal');
Route::get('/Mip/reservas/listarReserva', 'ReservaController@listarReserva');
Route::get('/Mip/reservas/listarReservaMenosOperaciones', 'ReservaController@listarReservaMenosOperaciones');
Route::get('/Mip/reservas/listarReservasOperaciones', 'ReservaController@listarReservasOperaciones');


Route::put('/reserva/Desactivar', 'ReservaController@desactivar');
Route::post('/Reserva/registrarOT', 'ReservaController@guardarOT');
Route::post('/reservas/validar', 'ReservaController@validarReserva');
Route::post('/reservas/validarAdmin', 'ReservaController@validarReservaAdmin');
Route::get('/reserva/verificarTecnicoDiaSig', 'ReservaController@verificarTecnicoDiaSig');
Route::post('/reservas/registrar', 'ReservaController@guardar');
Route::post('/reservas/registrarSinTecnicos', 'ReservaController@registrarSinTecnicos');
Route::post('/reservas/registrarReservaReplicacion', 'ReservaController@registrarReservaReplicacion');
Route::put('/reservas/modificarReserva', 'ReservaController@modificarReserva');


//DetalleReserva
Route::get('/DetalleReserva/listaDetalleReservasFechaActual', 'DetalleReservaController@listaDetalleReservasFechaActual');
Route::get('/listarTrabajadoresModificar', 'DetalleReservaController@listarTrabajadoresModificar');
Route::get('/DetalleReservaModificar', 'DetalleReservaController@listaReservaModificar');

//DetalleReservaMigracion
Route::get('/DetalleReservaMigracion/listaDetalleReservasFechaActualMigracion', 'DetalleReservaMigracionController@listaDetalleReservasFechaActualMigracion');

//Personal
Route::get('/personal', 'PersonalController@index');
Route::get('/personal/listadoActivo', 'PersonalController@listadoActivo');
Route::post('/personal/registrar', 'PersonalController@registrar');
Route::put('/personal/cambiarEstado', 'PersonalController@cambiarEstado');
Route::put('/personal/actualizar', 'PersonalController@actualizar');

//Tecnico
Route::get('/tecnico/listarReservasFechaUnTecnico', 'TecnicoController@listarReservasFechaUnTecnico');
Route::post('/tecnico/registrarReasignacion', 'TecnicoController@registrarReasignacion');
Route::get('/tecnico/listaTecnicoReservas', 'TecnicoController@listadoTecnicoReserva');
Route::get('/listaTecnico', 'TecnicoController@listadoTecnicos');
Route::get('/tecnico', 'TecnicoController@index');
Route::get('/tecnicos/listadoTecnicosFechaActual', 'TecnicoController@listadoTecnicosFechaActual');
Route::get('/tecnicos/listadoTecnicosFechaActualAdmin', 'TecnicoController@listadoTecnicosFechaActualAdmin');
Route::get('/tecnicos/listadoTecnicosFechaActualAdminAmbos', 'TecnicoController@listadoTecnicosFechaActualAdminAmbos');
Route::get('/tecnicos/listarOEF', 'TecnicoController@listarOEF');


//login
Route::get('/','Auth\LoginController@showLoginForm');
Route::get('/cerrar', function () {
    return view('principal');
});
//Route::get('/login', 'Auth\LoginController@login')->name('login');
Route::post('/login', 'UsuarioController@verificar')->name('login');
Route::get('/home', 'HomeController@index')->name('home');

//Menu
Route::get('/menu/Usuario', 'MenuController@listarMenu');
Route::get('/subMenu/listarMenus', 'MenuController@listarMenus');
Route::get('/subMenu', 'MenuController@index');
Route::get('/Menu/subMenu1', 'MenuController@listado');

Route::get('/Menu/subMenu10', 'MenuController@subMenu1');
Route::get('/Menu/Menu10', 'MenuController@Menu1');

//Cliente
Route::get('/Mip/Cliente/listadoActivo', 'ClienteController@listadoActivo');

Route::get('/Cliente', 'ClienteController@listado');
Route::get('/Mip/Cliente/listado', 'ClienteController@listaCliente');



Route::get('/Mip/Cliente/listaTipoCliente', 'ClienteController@listaTipoCliente');
Route::post('/cliente/registrar', 'ClienteController@registrar');

Route::get('/Mip/Cliente/ciudad', 'ClienteController@ciudad');
Route::get('/Mip/Cliente/ejecutivo', 'ClienteController@ejecutivo');
Route::put('/cliente/modificar', 'ClienteController@modificar');
Route::put('/cliente/cambiarEstado', 'ClienteController@cambiarEstado');





//Roles
Route::put('/roles/Desactivar', 'RolesController@desactivar');
Route::put('/roles/Activar', 'RolesController@activar');
Route::get('/rol/obtDetalleRoles', 'RolesController@obtDetalleRoles');
Route::get('/roles/listado', 'RolesController@listado');
Route::get('/roles/listadoActivos', 'RolesController@listadoActivos');
Route::post('/roles/registrar', 'RolesController@registrar');


//Detalle Equipo
Route::get('/detalleEquipo/listado', 'DetalleEquipoController@listado');


//Usuario
Route::put('/usuario/Desactivar', 'UsuarioController@desactivar');
Route::put('/usuario/Activar', 'UsuarioController@activar');
Route::get('/usuario/id', 'UsuarioController@obtId');
Route::get('/usuario/listado', 'UsuarioController@listado');
Route::post('/usuario/registrar', 'UsuarioController@registrar');
Route::post('/usuario/cerrarSession', 'UsuarioController@cerrarSession')->name('logout');

//Plagas
Route::get('/Mip/plagas/listar', 'PlagasController@listaPlagas');

//Lugares
Route::get('/Mip/lugares/listar', 'LugaresController@listaLugares');

//Orden Trabajo
Route::get('/Mip/ot/listar1', 'OrdenTrabajoController@listado1');
Route::get('/Mip/ot/listar', 'OrdenTrabajoController@listado');
Route::post('/Mip/ot/registrar', 'OrdenTrabajoController@guardar');
Route::get('/Mip/ot/idUsuario', 'OrdenTrabajoController@idUsuario');
Route::put('/ot/reprogramar', 'OrdenTrabajoController@reprogramar');
Route::put('/ot/suspender', 'OrdenTrabajoController@suspender');
Route::put('/ot/modificar', 'OrdenTrabajoController@modificar');


//reportes
Route::get('/Mip/listaOTEjecutivo', 'ReportesController@listadoOTEjecutivo');
Route::get('/Mip/listaOTEjecutivoFiltro', 'ReportesController@listadoOTEjecutivoFiltro');
Route::get('/Mip/listaFrecuencia', 'ReportesController@listadoFrecuencia');
Route::get('/Reportes/listarReservasMes', 'ReportesController@listarReservasMes');
Route::get('/Reportes/listarReservasMesF2', 'ReportesController@listarReservasMesF2');
Route::get('/Reportes/listarDetalleReservasMes', 'ReportesController@listarDetalleReservasMes');
Route::get('/Reportes/obtMes', 'ReportesController@obtMes');
Route::get('/Reportes/obtDiasMes', 'ReportesController@obtDiasMes');
Route::get('/pru', 'ReportesController@pru');



//Certificado Ejecutivo
Route::get('/Certificado/listar', 'CertificadoEjecutivoController@listadoCertificado');
Route::get('/Certificado/listadoOTCertificado', 'CertificadoEjecutivoController@listadoOTCertificado');
Route::post('/Certificado/registrar', 'CertificadoEjecutivoController@registrar');


//MAESTRO OEF - OPERACIONES EMPRESAS FIJAS
Route::get('/oef/listarDatos', 'MaestroOEFController@listarDatos');
Route::get('/oef/listar', 'MaestroOEFController@listaReservasPorGestion');
Route::get('/oef/listarTecnicosReserva', 'MaestroOEFController@listarTecnicosReserva');
Route::post('/oef/registrar', 'MaestroOEFController@registrar');
Route::get('/oef/listarDetalle', 'MaestroOEFController@listarDetalle');




